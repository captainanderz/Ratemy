﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace RateMy.com.Models
{
    public class AdminViewModel : LayoutViewModel
    {
        public List<ImageForWeb> ImagesWithInfo { get; set; }
    }
}